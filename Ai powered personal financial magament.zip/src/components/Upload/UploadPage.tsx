import React, { useCallback, useState } from 'react';
import { Upload, FileText, AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import { useFinanceStore } from '../../store/financeStore';

export const UploadPage: React.FC = () => {
  const [dragActive, setDragActive] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'success' | 'error'>('idle');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const { uploadBankStatement, isLoading } = useFinanceStore();

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  }, []);

  const handleFileUpload = async (file: File) => {
    if (!file) return;
    
    const validTypes = [
      'text/csv',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ];
    
    if (!validTypes.includes(file.type)) {
      setUploadStatus('error');
      return;
    }

    setUploadedFile(file);
    setUploadStatus('uploading');
    
    try {
      await uploadBankStatement(file);
      setUploadStatus('success');
      setTimeout(() => {
        setUploadStatus('idle');
        setUploadedFile(null);
      }, 3000);
    } catch (error) {
      setUploadStatus('error');
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileUpload(e.target.files[0]);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex items-center space-x-3">
        <div className="bg-primary-100 dark:bg-primary-900/30 p-3 rounded-lg">
          <Upload className="h-6 w-6 text-primary-600 dark:text-primary-400" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Upload Bank Statement
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Import your financial data for AI-powered analysis
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upload Area */}
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Upload File
          </h3>
          
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-colors ${
              dragActive
                ? 'border-primary-400 bg-primary-50 dark:bg-primary-900/20'
                : 'border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500'
            }`}
          >
            <input
              type="file"
              accept=".csv,.xlsx,.xls"
              onChange={handleFileSelect}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              disabled={isLoading}
            />
            
            <div className="space-y-4">
              {uploadStatus === 'uploading' || isLoading ? (
                <Loader2 className="h-12 w-12 text-primary-500 mx-auto animate-spin" />
              ) : uploadStatus === 'success' ? (
                <CheckCircle className="h-12 w-12 text-success-500 mx-auto" />
              ) : uploadStatus === 'error' ? (
                <AlertCircle className="h-12 w-12 text-danger-500 mx-auto" />
              ) : (
                <Upload className="h-12 w-12 text-gray-400 mx-auto" />
              )}
              
              <div>
                <h4 className="text-lg font-medium text-gray-900 dark:text-white">
                  {uploadStatus === 'uploading' || isLoading
                    ? 'Processing your file...'
                    : uploadStatus === 'success'
                    ? 'Upload successful!'
                    : uploadStatus === 'error'
                    ? 'Upload failed'
                    : 'Drop your bank statement here'
                  }
                </h4>
                <p className="text-gray-600 dark:text-gray-400 mt-1">
                  {uploadStatus === 'uploading' || isLoading
                    ? 'Our AI is analyzing your transactions...'
                    : uploadStatus === 'success'
                    ? `${uploadedFile?.name} has been processed successfully`
                    : uploadStatus === 'error'
                    ? 'Please check the file format and try again'
                    : 'Or click to browse files'
                  }
                </p>
              </div>
              
              {uploadStatus === 'idle' && (
                <div className="flex items-center justify-center space-x-4 text-sm text-gray-500 dark:text-gray-400">
                  <span>Supports: CSV, Excel</span>
                  <span>•</span>
                  <span>Max size: 10MB</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            How to Prepare Your Data
          </h3>
          
          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <div className="bg-primary-100 dark:bg-primary-900/30 p-2 rounded-lg">
                <FileText className="h-4 w-4 text-primary-600 dark:text-primary-400" />
              </div>
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white">
                  Download from Your Bank
                </h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Export your transaction history as CSV or Excel from your online banking portal.
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <div className="bg-success-100 dark:bg-success-900/30 p-2 rounded-lg">
                <CheckCircle className="h-4 w-4 text-success-600 dark:text-success-400" />
              </div>
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white">
                  Required Columns
                </h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Date, Description, Amount (and optionally Category).
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <div className="bg-warning-100 dark:bg-warning-900/30 p-2 rounded-lg">
                <AlertCircle className="h-4 w-4 text-warning-600 dark:text-warning-400" />
              </div>
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white">
                  Privacy & Security
                </h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Your data is processed locally and securely. We never store sensitive information.
                </p>
              </div>
            </div>
          </div>
          
          <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">
              What happens next?
            </h4>
            <ul className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
              <li>• Automatic transaction categorization</li>
              <li>• Spending pattern analysis</li>
              <li>• Personalized budget recommendations</li>
              <li>• Investment suggestions based on your profile</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Sample Data Format */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Expected File Format
        </h3>
        
        <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                <th className="text-left font-medium text-gray-700 dark:text-gray-300 pb-2">Date</th>
                <th className="text-left font-medium text-gray-700 dark:text-gray-300 pb-2">Description</th>
                <th className="text-left font-medium text-gray-700 dark:text-gray-300 pb-2">Amount</th>
                <th className="text-left font-medium text-gray-700 dark:text-gray-300 pb-2">Category</th>
              </tr>
            </thead>
            <tbody className="space-y-1">
              <tr className="text-gray-600 dark:text-gray-400">
                <td className="py-1">2024-01-15</td>
                <td className="py-1">Grocery Store XYZ</td>
                <td className="py-1">-125.50</td>
                <td className="py-1">Food & Dining</td>
              </tr>
              <tr className="text-gray-600 dark:text-gray-400">
                <td className="py-1">2024-01-14</td>
                <td className="py-1">Salary Deposit</td>
                <td className="py-1">3500.00</td>
                <td className="py-1">Income</td>
              </tr>
              <tr className="text-gray-600 dark:text-gray-400">
                <td className="py-1">2024-01-13</td>
                <td className="py-1">Gas Station</td>
                <td className="py-1">-45.00</td>
                <td className="py-1">Transportation</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};