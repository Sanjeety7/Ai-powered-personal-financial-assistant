import React, { useEffect } from 'react';
import { 
  DollarSign, 
  TrendingUp, 
  Target, 
  PiggyBank,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { StatsCard } from './StatsCard';
import { SpendingChart } from './SpendingChart';
import { useFinanceStore } from '../../store/financeStore';
import { SpendingCategory } from '../../types';

export const Dashboard: React.FC = () => {
  const { 
    financialData, 
    transactions, 
    goals, 
    insights,
    generateInsights 
  } = useFinanceStore();

  useEffect(() => {
    if (transactions.length > 0) {
      generateInsights();
    }
  }, [transactions, generateInsights]);

  // Calculate spending by category
  const spendingByCategory: SpendingCategory[] = React.useMemo(() => {
    const categoryTotals: { [key: string]: number } = {};
    const expenseTransactions = transactions.filter(t => t.type === 'expense');
    
    expenseTransactions.forEach(transaction => {
      categoryTotals[transaction.category] = (categoryTotals[transaction.category] || 0) + Math.abs(transaction.amount);
    });

    const total = Object.values(categoryTotals).reduce((sum, amount) => sum + amount, 0);
    
    return Object.entries(categoryTotals).map(([name, amount]) => ({
      name,
      amount,
      percentage: total > 0 ? Math.round((amount / total) * 100) : 0,
      color: ''
    }));
  }, [transactions]);

  // Calculate monthly data
  const monthlyIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);
  
  const monthlyExpenses = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + Math.abs(t.amount), 0);
  
  const monthlySavings = monthlyIncome - monthlyExpenses;
  const totalGoalsValue = goals.reduce((sum, goal) => sum + goal.targetAmount, 0);

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
          Financial Dashboard
        </h1>
        <div className="text-right">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Last updated
          </p>
          <p className="text-sm font-medium text-gray-900 dark:text-white">
            {new Date().toLocaleDateString()}
          </p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Monthly Income"
          value={`$${monthlyIncome.toLocaleString()}`}
          change="+12.5% from last month"
          changeType="positive"
          icon={DollarSign}
          description="Total income this month"
        />
        <StatsCard
          title="Monthly Expenses"
          value={`$${monthlyExpenses.toLocaleString()}`}
          change="-3.2% from last month"
          changeType="positive"
          icon={ArrowDownRight}
          description="Total expenses this month"
        />
        <StatsCard
          title="Net Savings"
          value={`$${monthlySavings.toLocaleString()}`}
          change={monthlySavings > 0 ? '+8.1%' : '-15.3%'}
          changeType={monthlySavings > 0 ? 'positive' : 'negative'}
          icon={PiggyBank}
          description="Income minus expenses"
        />
        <StatsCard
          title="Investment Goals"
          value={`$${totalGoalsValue.toLocaleString()}`}
          change={`${goals.length} active goals`}
          changeType="neutral"
          icon={Target}
          description="Total target amount"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Spending Breakdown */}
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              Spending Breakdown
            </h3>
            <TrendingUp className="h-5 w-5 text-primary-600 dark:text-primary-400" />
          </div>
          {spendingByCategory.length > 0 ? (
            <SpendingChart data={spendingByCategory} type="pie" />
          ) : (
            <div className="h-64 flex items-center justify-center">
              <p className="text-gray-500 dark:text-gray-400">
                No spending data available. Upload bank statements to get started.
              </p>
            </div>
          )}
        </div>

        {/* Recent Insights */}
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            AI Insights
          </h3>
          <div className="space-y-4">
            {insights.length > 0 ? (
              insights.slice(0, 3).map((insight) => (
                <div key={insight.id} className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900 dark:text-white">
                        {insight.title}
                      </h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                        {insight.content}
                      </p>
                    </div>
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      insight.priority === 'high' 
                        ? 'bg-danger-100 dark:bg-danger-900/30 text-danger-700 dark:text-danger-300'
                        : insight.priority === 'medium'
                        ? 'bg-warning-100 dark:bg-warning-900/30 text-warning-700 dark:text-warning-300'
                        : 'bg-gray-100 dark:bg-gray-600 text-gray-700 dark:text-gray-300'
                    }`}>
                      {insight.priority}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500 dark:text-gray-400">
                  Upload your financial data to receive AI-powered insights.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Quick Actions
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="p-4 bg-primary-50 dark:bg-primary-900/20 hover:bg-primary-100 dark:hover:bg-primary-900/30 rounded-lg transition-colors text-left">
            <ArrowUpRight className="h-6 w-6 text-primary-600 dark:text-primary-400 mb-2" />
            <h4 className="font-medium text-gray-900 dark:text-white">Add Transaction</h4>
            <p className="text-sm text-gray-600 dark:text-gray-400">Record a new income or expense</p>
          </button>
          
          <button className="p-4 bg-success-50 dark:bg-success-900/20 hover:bg-success-100 dark:hover:bg-success-900/30 rounded-lg transition-colors text-left">
            <Target className="h-6 w-6 text-success-600 dark:text-success-400 mb-2" />
            <h4 className="font-medium text-gray-900 dark:text-white">Set New Goal</h4>
            <p className="text-sm text-gray-600 dark:text-gray-400">Create a savings or investment goal</p>
          </button>
          
          <button className="p-4 bg-warning-50 dark:bg-warning-900/20 hover:bg-warning-100 dark:hover:bg-warning-900/30 rounded-lg transition-colors text-left">
            <DollarSign className="h-6 w-6 text-warning-600 dark:text-warning-400 mb-2" />
            <h4 className="font-medium text-gray-900 dark:text-white">Update Budget</h4>
            <p className="text-sm text-gray-600 dark:text-gray-400">Adjust your monthly budget</p>
          </button>
        </div>
      </div>
    </div>
  );
};