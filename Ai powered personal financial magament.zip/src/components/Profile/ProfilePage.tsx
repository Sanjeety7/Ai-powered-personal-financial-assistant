import React, { useState, useEffect } from 'react';
import { User, DollarSign, TrendingUp, Shield, Save } from 'lucide-react';
import { useFinanceStore } from '../../store/financeStore';
import { useAuthStore } from '../../store/authStore';

export const ProfilePage: React.FC = () => {
  const { user } = useAuthStore();
  const { financialData, updateFinancialData } = useFinanceStore();
  const [formData, setFormData] = useState({
    monthlyIncome: financialData?.monthlyIncome?.toString() || '',
    monthlyExpenses: financialData?.monthlyExpenses?.toString() || '',
    currentSavings: financialData?.currentSavings?.toString() || '',
    riskProfile: financialData?.riskProfile || 'medium',
    investmentPreferences: financialData?.investmentPreferences || []
  });

  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (financialData) {
      setFormData({
        monthlyIncome: financialData.monthlyIncome?.toString() || '',
        monthlyExpenses: financialData.monthlyExpenses?.toString() || '',
        currentSavings: financialData.currentSavings?.toString() || '',
        riskProfile: financialData.riskProfile || 'medium',
        investmentPreferences: financialData.investmentPreferences || []
      });
    }
  }, [financialData]);

  const investmentOptions = [
    'Stocks',
    'Bonds',
    'Index Funds',
    'ETFs',
    'Real Estate',
    'Cryptocurrency',
    'Mutual Funds',
    'CDs'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    updateFinancialData({
      monthlyIncome: parseFloat(formData.monthlyIncome) || 0,
      monthlyExpenses: parseFloat(formData.monthlyExpenses) || 0,
      currentSavings: parseFloat(formData.currentSavings) || 0,
      riskProfile: formData.riskProfile as 'low' | 'medium' | 'high',
      investmentPreferences: formData.investmentPreferences
    });

    setIsSaving(false);
  };

  const handleInvestmentPreferenceChange = (option: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      investmentPreferences: checked
        ? [...prev.investmentPreferences, option]
        : prev.investmentPreferences.filter(item => item !== option)
    }));
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex items-center space-x-3">
        <div className="bg-primary-100 dark:bg-primary-900/30 p-3 rounded-lg">
          <User className="h-6 w-6 text-primary-600 dark:text-primary-400" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Profile & Preferences
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Update your financial information for better AI recommendations
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* User Info */}
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
            <User className="h-5 w-5 mr-2" />
            Account Information
          </h3>
          
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                Full Name
              </label>
              <input
                type="text"
                value={user?.name || ''}
                readOnly
                className="mt-1 w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                Email Address
              </label>
              <input
                type="email"
                value={user?.email || ''}
                readOnly
                className="mt-1 w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                Member Since
              </label>
              <input
                type="text"
                value={user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : ''}
                readOnly
                className="mt-1 w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>
          </div>
        </div>

        {/* Financial Information Form */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6 flex items-center">
            <DollarSign className="h-5 w-5 mr-2" />
            Financial Information
          </h3>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Monthly Income
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.monthlyIncome}
                  onChange={(e) => setFormData({ ...formData, monthlyIncome: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                  placeholder="5000.00"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Monthly Expenses
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.monthlyExpenses}
                  onChange={(e) => setFormData({ ...formData, monthlyExpenses: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                  placeholder="3000.00"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Current Savings
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.currentSavings}
                  onChange={(e) => setFormData({ ...formData, currentSavings: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                  placeholder="10000.00"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                <Shield className="h-4 w-4 inline mr-1" />
                Risk Profile
              </label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {(['low', 'medium', 'high'] as const).map((risk) => (
                  <button
                    key={risk}
                    type="button"
                    onClick={() => setFormData({ ...formData, riskProfile: risk })}
                    className={`p-4 border-2 rounded-lg transition-colors text-left ${
                      formData.riskProfile === risk
                        ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20'
                        : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                    }`}
                  >
                    <h4 className="font-medium text-gray-900 dark:text-white capitalize">
                      {risk} Risk
                    </h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      {risk === 'low' 
                        ? 'Conservative, stable returns'
                        : risk === 'medium'
                        ? 'Balanced growth and stability'
                        : 'Aggressive growth potential'
                      }
                    </p>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                <TrendingUp className="h-4 w-4 inline mr-1" />
                Investment Preferences
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {investmentOptions.map((option) => (
                  <label
                    key={option}
                    className="flex items-center space-x-2 p-3 border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={formData.investmentPreferences.includes(option)}
                      onChange={(e) => handleInvestmentPreferenceChange(option, e.target.checked)}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                    />
                    <span className="text-sm text-gray-700 dark:text-gray-300">
                      {option}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={isSaving}
              className="w-full flex items-center justify-center space-x-2 py-3 px-4 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isSaving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  <span>Save Preferences</span>
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};