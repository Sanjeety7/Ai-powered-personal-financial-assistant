import React from 'react';
import { 
  Brain, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Lightbulb,
  ArrowRight,
  Download
} from 'lucide-react';
import { useFinanceStore } from '../../store/financeStore';
import jsPDF from 'jspdf';

export const InsightsPage: React.FC = () => {
  const { insights, transactions, financialData } = useFinanceStore();

  const generateReport = () => {
    const doc = new jsPDF();
    
    // Title
    doc.setFontSize(20);
    doc.text('Monthly Financial Report', 20, 30);
    
    // Date
    doc.setFontSize(12);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 45);
    
    // Summary
    doc.setFontSize(16);
    doc.text('Financial Summary', 20, 65);
    
    doc.setFontSize(12);
    const income = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
    const expenses = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + Math.abs(t.amount), 0);
    const savings = income - expenses;
    
    doc.text(`Monthly Income: $${income.toLocaleString()}`, 20, 80);
    doc.text(`Monthly Expenses: $${expenses.toLocaleString()}`, 20, 95);
    doc.text(`Net Savings: $${savings.toLocaleString()}`, 20, 110);
    
    // Insights
    doc.text('AI Insights & Recommendations', 20, 130);
    
    let yPosition = 145;
    insights.forEach((insight, index) => {
      if (yPosition > 250) {
        doc.addPage();
        yPosition = 30;
      }
      
      doc.setFontSize(11);
      doc.text(`${index + 1}. ${insight.title}`, 20, yPosition);
      yPosition += 15;
      
      const splitContent = doc.splitTextToSize(insight.content, 170);
      doc.text(splitContent, 25, yPosition);
      yPosition += splitContent.length * 5 + 10;
    });
    
    doc.save('financial-report.pdf');
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high':
        return <AlertTriangle className="h-5 w-5 text-danger-500" />;
      case 'medium':
        return <Lightbulb className="h-5 w-5 text-warning-500" />;
      default:
        return <CheckCircle className="h-5 w-5 text-success-500" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-danger-50 dark:bg-danger-900/20 border-danger-200 dark:border-danger-700';
      case 'medium':
        return 'bg-warning-50 dark:bg-warning-900/20 border-warning-200 dark:border-warning-700';
      default:
        return 'bg-success-50 dark:bg-success-900/20 border-success-200 dark:border-success-700';
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <div className="bg-primary-100 dark:bg-primary-900/30 p-3 rounded-lg">
            <Brain className="h-6 w-6 text-primary-600 dark:text-primary-400" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              AI Insights
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Personalized financial recommendations based on your data
            </p>
          </div>
        </div>
        
        <button
          onClick={generateReport}
          className="flex items-center space-x-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors"
        >
          <Download className="h-4 w-4" />
          <span>Export Report</span>
        </button>
      </div>

      {insights.length > 0 ? (
        <div className="space-y-6">
          {insights.map((insight) => (
            <div
              key={insight.id}
              className={`p-6 rounded-xl border-2 ${getPriorityColor(insight.priority)}`}
            >
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  {getPriorityIcon(insight.priority)}
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                      {insight.title}
                    </h3>
                    <span className={`px-3 py-1 text-xs font-medium rounded-full ${
                      insight.priority === 'high' 
                        ? 'bg-danger-100 dark:bg-danger-900/30 text-danger-700 dark:text-danger-300'
                        : insight.priority === 'medium'
                        ? 'bg-warning-100 dark:bg-warning-900/30 text-warning-700 dark:text-warning-300'
                        : 'bg-success-100 dark:bg-success-900/30 text-success-700 dark:text-success-300'
                    }`}>
                      {insight.priority.toUpperCase()} PRIORITY
                    </span>
                  </div>
                  
                  <p className="text-gray-700 dark:text-gray-300 mb-4 leading-relaxed">
                    {insight.content}
                  </p>
                  
                  <div>
                    <h4 className="font-medium text-gray-900 dark:text-white mb-2 flex items-center">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      Recommendations:
                    </h4>
                    <ul className="space-y-2">
                      {insight.recommendations.map((recommendation, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <ArrowRight className="h-4 w-4 text-primary-500 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-700 dark:text-gray-300 text-sm">
                            {recommendation}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white dark:bg-gray-800 p-12 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 text-center">
          <Brain className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            No Insights Available Yet
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-md mx-auto">
            Upload your financial data or add some transactions to receive personalized AI insights and recommendations.
          </p>
          <div className="flex justify-center space-x-4">
            <button className="px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors">
              Upload Bank Statement
            </button>
            <button className="px-6 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
              Add Manual Transaction
            </button>
          </div>
        </div>
      )}
    </div>
  );
};