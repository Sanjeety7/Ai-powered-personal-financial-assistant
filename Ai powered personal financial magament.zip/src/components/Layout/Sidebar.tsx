import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Home,
  CreditCard,
  Target,
  Brain,
  MessageSquare,
  Settings,
  Upload
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const location = useLocation();

  const menuItems = [
    { icon: Home, label: 'Dashboard', path: '/' },
    { icon: CreditCard, label: 'Transactions', path: '/transactions' },
    { icon: Target, label: 'Goals', path: '/goals' },
    { icon: Brain, label: 'AI Insights', path: '/insights' },
    { icon: MessageSquare, label: 'AI Chat', path: '/chat' },
    { icon: Upload, label: 'Upload Data', path: '/upload' },
    { icon: Settings, label: 'Profile', path: '/profile' }
  ];

  return (
    <aside className="hidden md:flex md:flex-col md:w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700">
      <nav className="flex-1 px-4 py-6 space-y-2">
        {menuItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 ${
                isActive
                  ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-r-2 border-primary-600'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-primary-600 dark:hover:text-primary-400'
              }`}
            >
              <item.icon className="h-5 w-5 mr-3" />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
};