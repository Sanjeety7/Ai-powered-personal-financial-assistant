import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { Transaction } from '../types';

export const parseCSV = (file: File): Promise<Transaction[]> => {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (result) => {
        try {
          const transactions = result.data.map((row: any, index: number) => {
            // Handle various CSV formats
            const date = new Date(row.Date || row.date || row.DATE);
            const amount = parseFloat(row.Amount || row.amount || row.AMOUNT || '0');
            const description = row.Description || row.description || row.DESC || 'Unknown transaction';
            const category = row.Category || row.category || categorizeTransaction(description);
            
            return {
              id: `csv-${Date.now()}-${index}`,
              userId: '1', // Mock user ID
              date,
              amount,
              description,
              category,
              type: amount >= 0 ? 'income' : 'expense' as 'income' | 'expense',
              createdAt: new Date()
            };
          });
          
          resolve(transactions.filter(t => !isNaN(t.amount)));
        } catch (error) {
          reject(error);
        }
      },
      error: (error) => reject(error)
    });
  });
};

export const parseExcel = (file: File): Promise<Transaction[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        
        const transactions = jsonData.map((row: any, index: number) => {
          const date = new Date(row.Date || row.date || row.DATE);
          const amount = parseFloat(row.Amount || row.amount || row.AMOUNT || '0');
          const description = row.Description || row.description || row.DESC || 'Unknown transaction';
          const category = row.Category || row.category || categorizeTransaction(description);
          
          return {
            id: `excel-${Date.now()}-${index}`,
            userId: '1', // Mock user ID
            date,
            amount,
            description,
            category,
            type: amount >= 0 ? 'income' : 'expense' as 'income' | 'expense',
            createdAt: new Date()
          };
        });
        
        resolve(transactions.filter(t => !isNaN(t.amount)));
      } catch (error) {
        reject(error);
      }
    };
    
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsBinaryString(file);
  });
};

// AI-powered transaction categorization (simplified)
export const categorizeTransaction = (description: string): string => {
  const desc = description.toLowerCase();
  
  if (desc.includes('restaurant') || desc.includes('food') || desc.includes('dining') || desc.includes('pizza') || desc.includes('coffee')) {
    return 'Food & Dining';
  }
  if (desc.includes('gas') || desc.includes('fuel') || desc.includes('uber') || desc.includes('taxi') || desc.includes('metro')) {
    return 'Transportation';
  }
  if (desc.includes('amazon') || desc.includes('shop') || desc.includes('store') || desc.includes('mall')) {
    return 'Shopping';
  }
  if (desc.includes('movie') || desc.includes('netflix') || desc.includes('spotify') || desc.includes('entertainment')) {
    return 'Entertainment';
  }
  if (desc.includes('electric') || desc.includes('water') || desc.includes('internet') || desc.includes('phone') || desc.includes('utility')) {
    return 'Bills & Utilities';
  }
  if (desc.includes('doctor') || desc.includes('hospital') || desc.includes('pharmacy') || desc.includes('medical')) {
    return 'Healthcare';
  }
  if (desc.includes('salary') || desc.includes('payroll') || desc.includes('wage')) {
    return 'Salary';
  }
  if (desc.includes('freelance') || desc.includes('contract') || desc.includes('consulting')) {
    return 'Freelance';
  }
  
  return 'Other';
};