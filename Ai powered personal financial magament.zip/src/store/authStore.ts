import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User } from '../types';

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  setUser: (user: User, token: string) => void;
}

// Mock authentication - in real app, this would connect to backend
const mockUsers: { [email: string]: { id: string; name: string; password: string; email: string } } = {
  'demo@example.com': {
    id: '1',
    name: 'Demo User',
    password: 'password123',
    email: 'demo@example.com'
  }
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      isAuthenticated: false,

      login: async (email: string, password: string) => {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const mockUser = mockUsers[email];
        if (mockUser && mockUser.password === password) {
          const user: User = {
            id: mockUser.id,
            email: mockUser.email,
            name: mockUser.name,
            createdAt: new Date()
          };
          const token = `mock-jwt-token-${Date.now()}`;
          
          set({
            user,
            token,
            isAuthenticated: true
          });
          return true;
        }
        return false;
      },

      register: async (name: string, email: string, password: string) => {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        if (mockUsers[email]) {
          return false; // User already exists
        }
        
        const id = (Object.keys(mockUsers).length + 1).toString();
        mockUsers[email] = { id, name, password, email };
        
        const user: User = {
          id,
          email,
          name,
          createdAt: new Date()
        };
        const token = `mock-jwt-token-${Date.now()}`;
        
        set({
          user,
          token,
          isAuthenticated: true
        });
        return true;
      },

      logout: () => {
        set({
          user: null,
          token: null,
          isAuthenticated: false
        });
      },

      setUser: (user: User, token: string) => {
        set({
          user,
          token,
          isAuthenticated: true
        });
      }
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({
        user: state.user,
        token: state.token,
        isAuthenticated: state.isAuthenticated
      })
    }
  )
);