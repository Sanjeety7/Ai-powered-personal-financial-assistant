import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { FinancialData, Transaction, Goal, AIInsight } from '../types';

interface FinanceState {
  financialData: FinancialData | null;
  transactions: Transaction[];
  goals: Goal[];
  insights: AIInsight[];
  isLoading: boolean;
  
  // Actions
  updateFinancialData: (data: Partial<FinancialData>) => void;
  addTransaction: (transaction: Omit<Transaction, 'id' | 'createdAt'>) => void;
  addGoal: (goal: Omit<Goal, 'id' | 'createdAt'>) => void;
  updateGoal: (goalId: string, updates: Partial<Goal>) => void;
  deleteGoal: (goalId: string) => void;
  generateInsights: () => void;
  uploadBankStatement: (file: File) => Promise<void>;
  setLoading: (loading: boolean) => void;
}

export const useFinanceStore = create<FinanceState>()(
  persist(
    (set, get) => ({
      financialData: null,
      transactions: [],
      goals: [],
      insights: [],
      isLoading: false,

      updateFinancialData: (data) => {
        const currentData = get().financialData;
        const updatedData: FinancialData = currentData
          ? { ...currentData, ...data, updatedAt: new Date() }
          : {
              id: Date.now().toString(),
              userId: '1', // Mock user ID
              monthlyIncome: 0,
              monthlyExpenses: 0,
              currentSavings: 0,
              riskProfile: 'medium',
              investmentPreferences: [],
              updatedAt: new Date(),
              ...data
            };
        
        set({ financialData: updatedData });
      },

      addTransaction: (transaction) => {
        const newTransaction: Transaction = {
          ...transaction,
          id: Date.now().toString(),
          createdAt: new Date()
        };
        
        set(state => ({
          transactions: [...state.transactions, newTransaction]
        }));
      },

      addGoal: (goal) => {
        const newGoal: Goal = {
          ...goal,
          id: Date.now().toString(),
          createdAt: new Date()
        };
        
        set(state => ({
          goals: [...state.goals, newGoal]
        }));
      },

      updateGoal: (goalId, updates) => {
        set(state => ({
          goals: state.goals.map(goal => 
            goal.id === goalId ? { ...goal, ...updates } : goal
          )
        }));
      },

      deleteGoal: (goalId) => {
        set(state => ({
          goals: state.goals.filter(goal => goal.id !== goalId)
        }));
      },

      generateInsights: () => {
        const { transactions, financialData } = get();
        
        if (!transactions.length || !financialData) return;

        // Generate AI-powered insights based on spending patterns
        const insights: AIInsight[] = [
          {
            id: '1',
            userId: '1',
            type: 'spending',
            title: 'High Food & Dining Expenses',
            content: 'You spent 35% more on food and dining this month compared to recommended budgets.',
            recommendations: [
              'Consider meal planning to reduce dining out',
              'Set a weekly food budget of $150',
              'Try cooking at home 4-5 days per week'
            ],
            priority: 'high',
            createdAt: new Date()
          },
          {
            id: '2',
            userId: '1',
            type: 'savings',
            title: 'Emergency Fund Goal',
            content: 'Based on your expenses, you should aim for 6 months of emergency savings.',
            recommendations: [
              'Target emergency fund: $18,000',
              'Save an additional $300/month',
              'Consider high-yield savings account'
            ],
            priority: 'medium',
            createdAt: new Date()
          },
          {
            id: '3',
            userId: '1',
            type: 'investment',
            title: 'Investment Opportunity',
            content: 'With your medium risk profile, consider diversified index fund investments.',
            recommendations: [
              'Allocate 70% to stock index funds',
              'Allocate 30% to bond funds',
              'Start with $500/month systematic investment'
            ],
            priority: 'medium',
            createdAt: new Date()
          }
        ];

        set({ insights });
      },

      uploadBankStatement: async (file) => {
        set({ isLoading: true });
        
        try {
          // Simulate file processing
          await new Promise(resolve => setTimeout(resolve, 2000));
          
          // Mock parsed transactions
          const mockTransactions: Transaction[] = [
            {
              id: Date.now().toString(),
              userId: '1',
              date: new Date('2024-01-15'),
              amount: -85.50,
              category: 'Food & Dining',
              description: 'Restaurant XYZ',
              type: 'expense',
              createdAt: new Date()
            },
            {
              id: (Date.now() + 1).toString(),
              userId: '1',
              date: new Date('2024-01-14'),
              amount: -120.00,
              category: 'Shopping',
              description: 'Online Store Purchase',
              type: 'expense',
              createdAt: new Date()
            },
            {
              id: (Date.now() + 2).toString(),
              userId: '1',
              date: new Date('2024-01-13'),
              amount: 3500.00,
              category: 'Salary',
              description: 'Monthly Salary',
              type: 'income',
              createdAt: new Date()
            }
          ];

          set(state => ({
            transactions: [...state.transactions, ...mockTransactions]
          }));
          
          // Generate new insights after processing
          get().generateInsights();
        } finally {
          set({ isLoading: false });
        }
      },

      setLoading: (loading) => set({ isLoading: loading })
    }),
    {
      name: 'finance-storage',
      partialize: (state) => ({
        financialData: state.financialData,
        transactions: state.transactions,
        goals: state.goals,
        insights: state.insights
      })
    }
  )
);