export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: Date;
}

export interface FinancialData {
  id: string;
  userId: string;
  monthlyIncome: number;
  monthlyExpenses: number;
  currentSavings: number;
  riskProfile: 'low' | 'medium' | 'high';
  investmentPreferences: string[];
  updatedAt: Date;
}

export interface Transaction {
  id: string;
  userId: string;
  date: Date;
  amount: number;
  category: string;
  description: string;
  type: 'income' | 'expense';
  createdAt: Date;
}

export interface Goal {
  id: string;
  userId: string;
  title: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: Date;
  category: string;
  createdAt: Date;
}

export interface AIInsight {
  id: string;
  userId: string;
  type: 'budget' | 'savings' | 'investment' | 'spending';
  title: string;
  content: string;
  recommendations: string[];
  priority: 'low' | 'medium' | 'high';
  createdAt: Date;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface SpendingCategory {
  name: string;
  amount: number;
  percentage: number;
  color: string;
}